# Moon Patrol for Roku
Remake of the classsic game Moon Patrol (1982) for Roku streaming devices and TVs

![Moon Patrol for Roku](http://lvcabral.com/images/MP/MoonPatrolIcon.png)

This is an ongoing project that I'm developing as a programming exercise.

There are two selectable sprite modes, the original Arcade machine graphics and Atari ST version.

Check out my other remake projects of classic games:
* [Prince of Persia for Roku](https://github.com/lvcabral/Prince-of-Persia-Roku)
* [Lode Runner for Roku](https://github.com/lvcabral/Lode-Runner-Roku)
* [Donkey Kong for Roku](https://www.youtube.com/watch?v=NA59qZk7fQU)

Disclaimer: This source code shall not be used commercially or sold in any form, the objective of this project is educational.

Marcelo Lv Cabral<br/>
http://lvcabral.com <br/>

Twitter: [@lvcabral](https://twitter.com/lvcabral)
